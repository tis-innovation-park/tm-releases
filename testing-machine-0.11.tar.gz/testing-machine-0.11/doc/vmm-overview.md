The Testing Machine's Virtual Machine Manager (tm-vvm) is a bunch of
wrapper scripts on top of existing Virtualization softwares. tm-vmm
makes it easier to start and stop such machines and execute program
(typically to perform tests) on these virtual machines.

tm-vmm is written in Bash and uses SSH to communicate/execute programs
on the various machines.

tm-vmm is part of Free Software Client Reference System (FSCRS). FSCRS
is a project at TIS Innovation Park in South Tyrol.
