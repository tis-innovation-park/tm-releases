# Writing Web tests

## Using Sikuli

## Using Selenium

