# Launching tests using VMM

## Using crontab

## Using Jenkins

