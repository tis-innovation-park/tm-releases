# e-Gov Testing Machine

The biggest hurdle to overcome in testing eGov services is getting past the login
prompt which requires a smart card and pin. Once login is successful testing can
begin using tools such as Selenium. Sikuli was used to overcome this obstacle since
we did not know how to do this with Selenium.

Run VMM  
Run Sikuli  
Deploy Selenium via command line  
Run tests  
Generate reports and send to host  
Stop VMM  
