# Example use:

/opt/bin/tm-vmm --check-client-status Ubuntu-12.10

/opt/bin/tm-vmm --check-client-status Ubuntu-12.10

/opt/bin/tm-vmm --check-client-ssh    Ubuntu-12.10

/opt/bin/tm-vmm --client-exec         Ubuntu-12.10 "pkcs15-tool -L"

