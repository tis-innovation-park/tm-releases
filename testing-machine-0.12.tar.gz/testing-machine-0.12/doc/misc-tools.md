# Miscallaneous other softwares

## Sikuli

Installing Java is a prerequisite for running Sikuli. Install it with apt-get:

`sudo apt-get install openjdk-6-jdk`

The software can be installed on Ubuntu 12.04 LTS with the following command:

`sudo apt-get install sikuli`

## GNU Xnee

## wmctrl

The package “wmctrl” is used to resize windows.

`sudo apt-get install wmctrl`

