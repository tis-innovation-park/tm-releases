# This is not the actual documentation

This directory contains documentation source files that are used to
build the vmm manuals. You can find the pre-built manuals at
[this repository](https://github.com/tis-innovation-park/tm-manuals).
