# FAQ

## General questions

## Virtualbox 

### Ubuntu as a host

* *Strange error: Enable VTx/AMD in BIOS*

![](faq-pics/Virtual_Box_Install_Error.png)

