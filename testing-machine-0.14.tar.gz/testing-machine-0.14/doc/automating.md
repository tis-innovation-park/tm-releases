# Launching tests using vmm

## Using crontab

## Using Jenkins

