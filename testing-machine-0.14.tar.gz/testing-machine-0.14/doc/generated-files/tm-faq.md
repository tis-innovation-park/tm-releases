# FAQ

## General questions

## Virtualbox 

### Host system is really slow 

* Check the Execution Cap in the settings for your Virtualbox client.


### Ubuntu as a host

* *Strange error: Enable VTx/AMD in BIOS*

![](faq-pics/Virtual_Box_Install_Error.png)

