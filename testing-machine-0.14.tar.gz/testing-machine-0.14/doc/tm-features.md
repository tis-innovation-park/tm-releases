# Features

## Virtual Machine Management

With Testing Machine you can:

* manage VirtualBox, Android, and QEMU virtual machines with a unified interface

* start/pause/stop virtual machines

* take screenshots of running virtual machines

* execute commands in running virtual machines
