# Virtual Machine Manager Developer's Guide

